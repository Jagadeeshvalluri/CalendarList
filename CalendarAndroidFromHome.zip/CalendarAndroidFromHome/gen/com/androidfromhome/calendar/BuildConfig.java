/** Automatically generated file. DO NOT MODIFY */
package com.androidfromhome.calendar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}